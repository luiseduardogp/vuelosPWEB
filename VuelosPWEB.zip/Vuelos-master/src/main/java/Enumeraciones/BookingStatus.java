package Enumeraciones;

public enum BookingStatus {
    UNCONFIRMED,
    CONFIRMED,
    CANCELLED
}
