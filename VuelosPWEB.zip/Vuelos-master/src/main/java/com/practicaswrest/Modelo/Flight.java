package com.practicaswrest.Modelo;



import com.fasterxml.jackson.annotation.JsonFormat;

import javax.persistence.*;
import java.util.Date;
import java.util.Set;

@Entity
@Table(name = "flight")
public class Flight {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idf;

    @Column
    private String departureDate;

    @Column
    private String departureAirportCode;

    @Column
    private String departureAirportName;

    @Column
    private String departureCity;

    @Column
    private String departureLocale;

    @Column
    private String arrivalDate;

    @Column
    private String arrivalAirportCode;

    @Column
    private String arrivalAirportName;

    @Column
    private String arrivalCity;

    @Column
    private String arrivalLocale;

    @Column
    private int ticketPrice;

    @Column
    private  String ticketCurrency;

    @Column
    private  int flightNumber;

    @Column
    private int seatCapacity;

    @OneToMany(mappedBy = "flight")
    private Set<Booking> bookingSet;

    public Flight() {
    }

    public Flight(String departureDate, String departureAirportCode, String departureAirportName, String departureCity, String departureLocale, String arrivalDate, String arrivalAirportCode, String arrivalAirportName, String arrivalCity, String arrivalLocale, int ticketPrice, String ticketCurrency, int flightNumber, int seatCapacity, Set<Booking> bookingSet) {
        this.departureDate = departureDate;
        this.departureAirportCode = departureAirportCode;
        this.departureAirportName = departureAirportName;
        this.departureCity = departureCity;
        this.departureLocale = departureLocale;
        this.arrivalDate = arrivalDate;
        this.arrivalAirportCode = arrivalAirportCode;
        this.arrivalAirportName = arrivalAirportName;
        this.arrivalCity = arrivalCity;
        this.arrivalLocale = arrivalLocale;
        this.ticketPrice = ticketPrice;
        this.ticketCurrency = ticketCurrency;
        this.flightNumber = flightNumber;
        this.seatCapacity = seatCapacity;
        this.bookingSet = bookingSet;
    }

    public int getId() {
        return idf;
    }

    public void setId(int id) {
        this.idf = idf;
    }



    public String getDepartureAirportCode() {
        return departureAirportCode;
    }

    public void setDepartureAirportCode(String departureAirportCode) {
        this.departureAirportCode = departureAirportCode;
    }

    public String getDepartureAirportName() {
        return departureAirportName;
    }

    public void setDepartureAirportName(String departureAirportName) {
        this.departureAirportName = departureAirportName;
    }

    public String getDepartureCity() {
        return departureCity;
    }

    public void setDepartureCity(String departureCity) {
        this.departureCity = departureCity;
    }

    public String getDepartureLocale() {
        return departureLocale;
    }

    public void setDepartureLocale(String departureLocale) {
        this.departureLocale = departureLocale;
    }


    public String getArrivalAirportCode() {
        return arrivalAirportCode;
    }

    public void setArrivalAirportCode(String arrivalAirportCode) {
        this.arrivalAirportCode = arrivalAirportCode;
    }

    public String getArrivalAirportName() {
        return arrivalAirportName;
    }

    public void setArrivalAirportName(String arrivalAirportName) {
        this.arrivalAirportName = arrivalAirportName;
    }

    public String getArrivalCity() {
        return arrivalCity;
    }

    public void setArrivalCity(String arrivalCity) {
        this.arrivalCity = arrivalCity;
    }

    public String getArrivalLocale() {
        return arrivalLocale;
    }

    public void setArrivalLocale(String arrivalLocale) {
        this.arrivalLocale = arrivalLocale;
    }

    public int getTicketPrice() {
        return ticketPrice;
    }

    public void setTicketPrice(int ticketPrice) {
        this.ticketPrice = ticketPrice;
    }

    public String getTicketCurrency() {
        return ticketCurrency;
    }

    public void setTicketCurrency(String ticketCurrency) {
        this.ticketCurrency = ticketCurrency;
    }

    public int getFlightNumber() {
        return flightNumber;
    }

    public void setFlightNumber(int flightNumber) {
        this.flightNumber = flightNumber;
    }

    public int getSeatCapacity() {
        return seatCapacity;
    }

    public void setSeatCapacity(int seatCapacity) {
        this.seatCapacity = seatCapacity;
    }

    public String getDepartureDate() {
        return departureDate;
    }

    public void setDepartureDate(String departureDate) {
        this.departureDate = departureDate;
    }

    public String getArrivalDate() {
        return arrivalDate;
    }

    public void setArrivalDate(String arrivalDate) {
        this.arrivalDate = arrivalDate;
    }

    public Set<Booking> getBookingSet() {
        return bookingSet;
    }

    public void setBookingSet(Set<Booking> bookingSet) {
        this.bookingSet = bookingSet;
    }
}
