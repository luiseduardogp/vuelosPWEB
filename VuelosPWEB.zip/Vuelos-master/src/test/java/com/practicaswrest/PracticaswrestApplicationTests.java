package com.practicaswrest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracticaswrestApplicationTests {

	@Test
	void contextLoads() {
	}

}
